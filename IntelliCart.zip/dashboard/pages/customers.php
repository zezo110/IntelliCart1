<?php
include('../inc/header.php');
?>

<!-- PAGE-HEADER -->
<div class="page-header">
    <h1 class="page-title">All Customers</h1>
    <div>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Customers</li>
        </ol>
    </div>
</div>
<!-- PAGE-HEADER END -->

<!--===CUSTOMERS TABLE===-->
<div class="row">
    <div class="col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title mb-0">Customers</h3>
            </div>
            <div class="card-body pt-4">
                <div class="grid-margin">
                    <div class="">
                        <div class="panel panel-primary">
                            <div class="tab-menu-heading border-0 p-0">
                            </div>
                            <div class="panel-body tabs-menu-body border-0 pt-0">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="tab5">
                                        <div class="table-responsive">
                                            <table id="data-table" class="table table-bordered text-nowrap mb-0">
                                                <thead class="border-top">
                                                    <tr>
                                                        <th class="bg-transparent border-bottom-0">Email</th>
                                                        <th class="bg-transparent border-bottom-0">Date</th>
                                                        <th class="bg-transparent border-bottom-0">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    // اتصال بقاعدة البيانات
                                                    $servername = "localhost";
                                                    $username = "root";
                                                    $password = "";
                                                    $dbname = "user";
                                                    $conn = new mysqli($servername, $username, $password, $dbname);

                                                    if ($conn->connect_error) {
                                                        die("Connection failed: " . $conn->connect_error);
                                                    }

                                                    // استعلام SQL لاسترجاع العملاء
                                                    $sql = "SELECT * FROM user_info";
                                                    $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            echo '<tr class="border-bottom">';
                                                            echo '<td>';
                                                            echo '<div class="d-flex">';
                                                            echo '<span class="avatar bradius" style="background-image: url(../assets/images/orders/10.jpg)"></span>';
                                                            echo '<div class="ms-3 mt-0 mt-sm-2 d-block">';
                                                            echo '<h6 class="mb-0 fs-14 fw-semibold">' . $row['email'] . '</h6>';
                                                            echo '</div>';
                                                            echo '</div>';
                                                            echo '</td>';
                                                            echo '<td><span class="mt-sm-2 d-block">' . $row['date'] . '</span></td>';
                                                            echo '<td>';
                                                            echo '<a class="btn text-danger btn-sm" href="delete-customer.php?email=' . $row['email'] . '" data-bs-toggle="tooltip" data-bs-original-title="Delete"><span class="fe fe-trash-2 fs-14"></span></a>';
                                                            echo '</td>';
                                                            echo '</tr>';
                                                        }
                                                    } else {
                                                        echo '<p>No customers found.</p>';
                                                    }

                                                    $conn->close();
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('../inc/footer.php');
?>
