<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $orderId = $_GET['id'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // استعلام SQL لتغيير حالة الطلب
    $sql = "UPDATE orders SET order_status = 'complete' WHERE order_id = $orderId";

    if ($conn->query($sql) === TRUE) {
        echo "تم تغيير حالة الطلب إلى مكتمل بنجاح.";

        // إعادة التوجيه إلى صفحة orders.php بعد تغيير حالة الطلب
        header("Location: orders.php");
        exit();
    } else {
        echo "Error changing order status: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid request.";
}
?>