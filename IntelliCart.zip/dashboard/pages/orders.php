<?php
include('../inc/header.php');
?>

<!-- PAGE-HEADER -->
<div class="page-header">
    <h1 class="page-title">All Products</h1>
    <div>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Products</li>
        </ol>
    </div>
</div>
<!-- PAGE-HEADER END -->

<!--===ORDERS TABLE===-->
<div class="row">
    <div class="col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title mb-0">Orders</h3>
            </div>
            <div class="card-body pt-4">
                <div class="grid-margin">
                    <div class="">
                        <div class="panel panel-primary">
                            <div class="tab-menu-heading border-0 p-0">
                            </div>
                            <div class="panel-body tabs-menu-body border-0 pt-0">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="tab5">
                                        <div class="table-responsive">
                                            <table id="data-table" class="table table-bordered text-nowrap mb-0">
                                                <thead class="border-top">
                                                    <tr>
                                                        <th class="bg-transparent border-bottom-0">Product id</th>
                                                        <th class="bg-transparent border-bottom-0">Date</th>
                                                        <th class="bg-transparent border-bottom-0">Amount</th>
                                                        <th class="bg-transparent border-bottom-0">Name</th>
                                                        <th class="bg-transparent border-bottom-0">Address</th>
                                                        <th class="bg-transparent border-bottom-0">Phone</th>
                                                        <th class="bg-transparent border-bottom-0">Status</th>
                                                        <th class="bg-transparent border-bottom-0">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    // اتصال بقاعدة البيانات
                                                    $servername = "localhost";
                                                    $username = "root";
                                                    $password = "";
                                                    $dbname = "user";
                                                    $conn = new mysqli($servername, $username, $password, $dbname);

                                                    if ($conn->connect_error) {
                                                        die("Connection failed: " . $conn->connect_error);
                                                    }

                                                    // استعلام SQL لاسترجاع الطلبات
                                                    $sql = "SELECT orders.*, order_items.*, products.image
                                                    FROM orders
                                                    INNER JOIN order_items ON orders.order_id = order_items.order_id
                                                    INNER JOIN products ON order_items.product_id = products.id;
                                                    ";                                                    
                                                 $result = $conn->query($sql);

                                                    if ($result->num_rows > 0) {
                                                        while ($row = $result->fetch_assoc()) {
                                                            echo '<tr class="border-bottom">';
                                                            echo '<td>';
                                                            echo '<div class="d-flex">';
                                                            echo '<span class="avatar bradius" style="background-image: url(data:image/jpeg;base64,' . base64_encode($row['image']) . ')"></span>';
                                                            echo '<div class="ms-3 mt-0 mt-sm-2 d-block">';
                                                            echo '<h6 class="mb-0 fs-14 fw-semibold">' . $row['product_id'] . '</h6>';
                                                            echo '</div>';
                                                            echo '</div>';
                                                            echo '</td>';
                                                            echo '<td><span class="mt-sm-2 d-block">' . $row['order_date'] . '</span></td>';
                                                            echo '<td><span class="fw-semibold mt-sm-2 d-block">$' . $row['total_price'] . '</span></td>';
                                                            echo '<td><span class="fw-semibold mt-sm-2 d-block">' . $row['name'] . '</span></td>';
                                                            echo '<td><span class="fw-semibold mt-sm-2 d-block">' . $row['address'] . '</span></td>';
                                                            echo '<td><span class="fw-semibold mt-sm-2 d-block">' . $row['phone'] . '</span></td>';
                                                            echo '<td><span class="fw-semibold mt-sm-2 d-block">' . $row['order_status'] . '</span></td>';
                                                            echo '<td>';
                                                            echo '<div class="g-2">';
                                                            echo '<a class="btn text-danger btn-sm" href="delete-order.php?id=' . $row['order_id'] . '" data-bs-toggle="tooltip" data-bs-original-title="Delete"><span class="fe fe-trash-2 fs-14"></span></a>';
                                                            echo '<a class="btn text-success btn-sm" href="change-status.php?id=' . $row['order_id'] . '" data-bs-toggle="tooltip" data-bs-original-title="Change Status"><span class="fe fe-check-circle fs-14"></span></a>';
                                                            echo '</div>';
                                                            echo '</td>';
                                                            echo '</tr>';
                                                        }
                                                    } else {
                                                        echo '<p>No orders found.</p>';
                                                    }

                                                    $conn->close();
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('../inc/footer.php');
?>
