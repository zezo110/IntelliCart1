<?php
include('../inc/header.php');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['rating_id'])) {
    $ratingId = $_GET['rating_id'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // استعلام SQL لحذف المراجعة
    $sql = "DELETE FROM product_ratings WHERE rating_id = $ratingId";

    if ($conn->query($sql) === TRUE) {
        echo "Review deleted successfully";
    } else {
        echo "Error deleting rating: " . $conn->error;
    }

    $conn->close();

    // إعادة التوجيه إلى صفحة product-ratings.php بعد الحذف
    header("Location: product-ratings.php");
    exit();
} else {
    echo "Invalid request.";
}

include('../inc/footer.php');
?>