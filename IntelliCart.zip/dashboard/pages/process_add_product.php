<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['addProduct'])) {
    // اتصال بقاعدة البيانات
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // استلام البيانات من النموذج
    $productName = $_POST['productName'];
    $price = $_POST['price'];
    $categoryID = $_POST['categoryID'];
    $description = $_POST['description'];

    // استلام الصورة المرفوعة
    $image = $_FILES['image'];
    $imageName = $image['name'];
    $imageTmpName = $image['tmp_name'];
    $imageSize = $image['size'];
    $imageError = $image['error'];

    // التحقق من عدم حدوث أخطاء في الرفع
    if ($imageError === 0) {
        // قم بتحويل الصورة إلى تسلسل بنائي
        $imageContent = addslashes(file_get_contents($imageTmpName));

        // إضافة البيانات إلى جدول المنتجات
        $dateAdded = date("Y-m-d");
        $sql = "INSERT INTO products (PD_name, price, category_id, description, date_added, image) VALUES ('$productName', $price, $categoryID, '$description', '$dateAdded', '$imageContent')";

        if ($conn->query($sql) === TRUE) {
            echo "Product added successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Problem occured when try to load a photo.";
    }

    $conn->close();
}
?>
