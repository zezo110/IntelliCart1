<?php
include('../inc/header.php');
include('vendor/autoload.php');

use Sentiment\Analyzer;
$obj = new Analyzer();
?>

<style>
    body {
        text-align: center;
        font-family: Arial, sans-serif;
    }

    table {
        border-collapse: collapse;
        width: 100%;
    }

    table, th, td {
        border: 1px solid black;
        padding: 8px;
    }

    .main-div {
        width: 80%;
        margin: 50px auto;
        padding: 20px;
        box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        background-color: #fff;
    }
    .product-details {
    border: 1px solid #ddd;
    padding: 20px;
    margin-bottom: 20px;
    border-radius: 10px;
    background-color: #ffffff; 
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05); 
}

.product-details h1 {
    color: #333;
    font-size: 28px;
    margin-bottom: 15px;
}

.product-name {
    background-color: #f9f9f9;
    color: #333;
    font-size: 20px;
    padding: 10px;
    border-radius: 5px;
    box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
    margin-bottom: 20px;
}

.product-description {
    background-color: #ffffff;
    color: #555;
    font-size: 16px;
    padding: 10px;
    border: 1px solid #eee;
    border-radius: 5px;
    box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
    margin-bottom: 20px;
    line-height: 1.5;
}

.product-price {
    font-size: 24px;
    font-weight: bold;
    color: #FFFFFF; 
    padding: 10px 20px;
    display: inline-block;
    border-radius: 20px;
    background-color: #007bff; 
    box-shadow: 0 2px 4px rgba(76, 175, 80, 0.2); 
    margin: 20px 0;
}


    .avatar {
        width: 200px;
        height: 200px;
        display: block; 
        margin: 0 auto 20px; 
        background-size: cover;
        border-radius: 5px;
    }

    .input-box {
        width: 150px;
        height: 30px;
        margin-bottom: 15px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .input-btn {
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .input-btn:hover {
        background-color: #0056b3;
    }

    .product-link {
        display: inline-block;
        margin: 5px;
        padding: 10px;
        background-color: lightblue;
        border-radius: 5px;
        text-decoration: none;
        color: #333;
    }

    .product-link:hover {
        background-color: lightgray;
    }

    .ratings-container {
        display: flex;
        justify-content: space-around;
        margin-top: 20px;
    }

    .rating-item {
        flex: 1;
        padding: 15px;
        background-color: #f5f5f5;
        border-radius: 5px;
        margin: 0 10px;
    }

    .rating-label {
        font-size: 16px;
        font-weight: bold;
        color: #333;
    }

    .rating-value {
        font-size: 24px;
        color: #007bff;
    }
    .highlight {
        font-weight: bold;
        font-size: 20px;
    }
    .positive {
        color: #006400; 
    }
    .negative {
        color: #8B0000;
    }
    .advice-cell {
        font-size: 18px;
        text-align: center;
        padding: 10px;
        border-radius: 5px;
    }
    .product-name-title, .product-description-title {
    display: block;
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 5px;
    color: #007bff;
}

.product-name-content, .product-description-content {
    font-size: 16px;
    padding: 10px;
    background-color: #f8f9fa; 
    border: 1px solid #ddd;
    border-radius: 5px;
    color: #212529; 
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
}


</style>

<body>

    <!-- PAGE-HEADER -->
    <div class="page-header">
        <h1 class="page-title">All Products</h1>
        <div>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Products</li>
            </ol>
        </div>
    </div>
    <!-- PAGE-HEADER END -->

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Error connecting: " . $conn->connect_error);
    }

    $product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result_product = $stmt->get_result();
    $stmt->close();

    if ($result_product->num_rows > 0) {
        echo "<div class='product-details'>";
        while ($row_product = $result_product->fetch_assoc()) {
            echo "<h1>Product Details</h1>";
            $imageData = base64_encode($row_product['image']);
            $imageSrc = "data:image/png;base64,{$imageData}";
            echo "<div style='background-image: url($imageSrc); width: 200px; height: 200px; background-size: cover; border-radius: 100%; margin: auto;'></div>"; 
            echo "<span class='product-name-title'>Product Name</span>";
            echo "<div class='product-name-content'>" . htmlspecialchars($row_product['PD_name']) . "</div>";
            echo "<span class='product-description-title'>Description</span>";
            echo "<div class='product-description-content'>" . htmlspecialchars($row_product['description']) . "</div>";
            echo "<div class='product-price'>Price: $" . htmlspecialchars($row_product['price']) . "</div>"; 
        }
        echo "</div>";
    } else {
        echo "<p style='color: red;'>No product data available.</p>";
    }

    echo "<div style='border: 1px solid #ccc; padding: 10px; margin-bottom: 20px;'>";
    echo "<h2>Product Ratings and Sales</h2>";
    echo "<table style='border-collapse: collapse; width: 100%;'>";
    echo "<tr>
            <th>Total Reviews</th>
            <th>Average Rating</th>
            <th>Total Quantity Sold</th>
            <th>Total Sales</th>
          </tr>";


    $sql_ratings = "SELECT product_id, COUNT(rating_id) AS total_reviews, AVG(rating) AS average_rating
                    FROM product_ratings
                    WHERE product_id = $product_id
                    GROUP BY product_id";
    $result_ratings = $conn->query($sql_ratings);

    $sql_sales = "SELECT product_id, SUM(quantity) AS total_quantity, SUM(price_per_item * quantity) AS total_buy
                    FROM order_items
                    WHERE product_id = $product_id
                    GROUP BY product_id";
    $result_sales = $conn->query($sql_sales);

    if ($result_ratings->num_rows > 0 && $result_sales->num_rows > 0) {
        $row_ratings = $result_ratings->fetch_assoc();
        $row_sales = $result_sales->fetch_assoc();

        echo "<tr>";
        echo "<td>{$row_ratings['total_reviews']}</td>";
        echo "<td>" . number_format($row_ratings['average_rating'], 2) . "</td>";
        echo "<td>{$row_sales['total_quantity']}</td>";
        echo "<td>{$row_sales['total_buy']}</td>";
        echo "</tr>";
    } else {
        echo "<tr>";
        echo "<td colspan='4' style='text-align: center;'>No ratings or sales data available for the product</td>";
        echo "</tr>";
    }

    // تحليل
    $sql_comments = "SELECT comment FROM product_ratings WHERE product_id = ?";
    $stmt = $conn->prepare($sql_comments);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result_comments = $stmt->get_result();
    $stmt->close();
    
    $stopWords = ["the", "is", "at", "of", "on", "and", "a", "to", "in"];
    $sentiments = [];
    $wordCounts = [];
// تهيئة متغيرات لتخزين عدد التعليقات الإيجابية، السلبية، والمحايدة
$positiveCount = 0;
$negativeCount = 0;
$neutralCount = 0;

if ($result_comments->num_rows > 0) {
    while ($row = $result_comments->fetch_assoc()) {
        $comment = $row['comment'];
        $analysisResult = $obj->getSentiment($comment);

        if ($analysisResult['compound'] > 0.05) {
            $positiveCount++;
        } elseif ($analysisResult['compound'] < -0.05) {
            $negativeCount++;
        } else {
            $neutralCount++;
        }
    }

    $totalComments = $positiveCount + $negativeCount + $neutralCount;

    $minCommentsForAnalysis = 5;

if ($totalComments >= $minCommentsForAnalysis) {
        $positivePercentage = ($positiveCount / $totalComments) * 100;
        $negativePercentage = ($negativeCount / $totalComments) * 100;
        $neutralPercentage = ($neutralCount / $totalComments) * 100;
    
        if ($positivePercentage > $negativePercentage && $positivePercentage > $neutralPercentage) {
            $sentimentStatus = $positivePercentage >= 85 ? "Highly Positive" : ($positivePercentage > 70 ? "Positive" : "Almost Positive");
            $backgroundStyle = $positivePercentage >= 85 ? "#66CDAA" : ($positivePercentage > 70 ? "#8FBC8F" : "#98FB98"); 
        } elseif ($negativePercentage > $positivePercentage && $negativePercentage > $neutralPercentage) {
            $sentimentStatus = $negativePercentage >= 85 ? "Highly Negative" : ($negativePercentage > 70 ? "Negative" : "Almost Negative");
            $backgroundStyle = $negativePercentage >= 85 ? "#CD5C5C" : ($negativePercentage > 70 ? "#F08080" : "#FA8072");
        } else {
            $sentimentStatus = "Neutral";
            $backgroundStyle = "#F0E68C"; 
        }
    
        $sentimentPercentage = round(max($positivePercentage, $negativePercentage), 2);
        $adviceStyle = "style='background-color: $backgroundStyle;'";
        $bigramsArray = [];
        $stopWords = ["the", "is", "at", "of", "on", "and", "a", "to", "in", "product" ,"am" , "i"];
        $bigramCounts = [];

        if ($totalComments >= $minCommentsForAnalysis) {
            // جمع التراكيب اللفظية من التعليقات
            foreach ($result_comments as $row) {
                $comment = strtolower($row['comment']);
                $words = preg_split('/\s+/', preg_replace('/[^a-z0-9\s]/i', '', $comment));
                $words = array_diff($words, $stopWords); // إزالة الكلمات المتوقفة
                $words = array_values($words); // إعادة تهيئة المفاتيح بعد الإزالة
        
                for ($i = 0; $i < count($words) - 1; $i++) {
                    $bigram = $words[$i] . ' ' . $words[$i + 1];
                    if (!isset($bigramCounts[$bigram])) {
                        $bigramCounts[$bigram] = 1;
                    } else {
                        $bigramCounts[$bigram]++;
                    }
                }
            }
            
        
            arsort($bigramCounts);
            $mostFrequentBigrams = array_slice(array_keys($bigramCounts), 0, 1);
        
            // إعداد النصيحة بناءً على الحالة العامة
            $advice = "Consider focusing on improving aspects mentioned in comments.";
            if ($sentimentStatus == "Highly Positive") {
                $advice = "Keep up the good work! Your customers appreciate the quality.";
            } elseif ($sentimentStatus == "Highly Negative") {
                $advice = "Urgent attention needed! Look into customer complaints immediately.";
            }
        
            // عرض النتائج
            $bigramsText = implode(" and ", $mostFrequentBigrams);
            echo "<tr><td colspan='4' class='advice-cell' $adviceStyle>";
            echo "<p><span style='font-weight: bold';> Summary of reviews: </span> Overall sentiment is: <span style='font-weight: bold; text-decoration: underline;'>$sentimentStatus</span>.</p>";
            echo "<p><span style='font-weight: bold';> Advice:</span> <span style='color: green;'>$advice</span></p>";
            echo "<p><span style='font-weight: bold;'>Most frequent phrases:</span> <span style='background-color: #FFFFFF; font-style: italic;'>$bigramsText</span></p>";
            echo "</td></tr>";
                    } else {
            echo "<tr><td colspan='4' class='advice-cell'>Not enough data for analysis, Need at least $minCommentsForAnalysis comments.</td></tr>";
        }
}    
}

echo "</table>";
echo "</div>";

    ?>  

      <!-- comment -->

    <div class="main-div">
        <h2>Product Ratings:</h2>
        <?php
        $sql = "SELECT * FROM product_ratings WHERE product_id = $product_id";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $productName = htmlspecialchars($row['comment']);
                echo "<a class='product-link' href='javascript:void(0);' onclick='loadComments(\"$productName\")'>$productName</a>";
            }
        } else {
            echo "<p>No ratings available for this product.</p>";
        }
        ?>
        <div id="comments-container"></div>
        <div id="sentiment_chart" style="width: 900px; height: 500px;"></div>
    </div>
    
    <script>
        function loadComments(productName) {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("comments-container").innerHTML = this.responseText;
                }
            };
            xhr.open("GET", "load_comments.php?product_name=" + encodeURIComponent(productName), true);
            xhr.send();
        }
    </script>

    <?php
    include('../inc/footer.php');
    ?>
</body>
</html> 