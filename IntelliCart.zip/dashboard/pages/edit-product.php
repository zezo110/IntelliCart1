<?php
include('../inc/header.php');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

// اتصال بقاعدة البيانات
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// استعلام للحصول على بيانات المنتج المحدد
$productID = $_GET['id']; // افتراضيًا يجب تلقي ID المنتج من الرابط
$sql = "SELECT * FROM products WHERE id = $productID";
$result = $conn->query($sql);

// فحص إذا كان هناك بيانات للمنتج
if ($result->num_rows > 0) {
    $productData = $result->fetch_assoc();
} else {
    echo "لم يتم العثور على بيانات المنتج.";
    exit();
}

$conn->close();
?>

<!-- صفحة تعديل المنتج -->
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Edit Product</div>
            </div>
            <div class="card-body">
                <form method="post" action="update-product.php" enctype="multipart/form-data">
                    <!-- إضافة حقل مخفي لتمرير ID المنتج -->
                    <input type="hidden" name="product_id" value="<?php echo $productData['id']; ?>">

                    <!-- باقي الحقول... -->

                    <div class="row mb-4">
                        <label class="col-md-3 form-label">Product Name :</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" name="product_name" placeholder="Product Name" value="<?php echo $productData['PD_name']; ?>">
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-md-3 form-label">Price :</label>
                        <div class="col-md-9">
                            <input type="number" class="form-control" name="price" value="<?php echo $productData['price']; ?>">
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-md-3 form-label">Categories :</label>
                        <div class="col-md-9">
                            <select name="category_id" class="form-control form-select select2" data-bs-placeholder="Select Category">
                                <option value="1" <?php echo ($productData['category_id'] == 1) ? 'selected' : ''; ?>>Men</option>
                                <option value="2" <?php echo ($productData['category_id'] == 2) ? 'selected' : ''; ?>>Women</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-md-3 form-label mb-4">Product Description :</label>
                        <div class="col-md-9 mb-4">
                            <textarea class="content" name="description"><?php echo $productData['description']; ?></textarea>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-md-3 form-label">Product Image :</label>
                        <div class="col-md-9">
                            <input type="file" class="form-control" name="image" accept=".jpg, .png, image/jpeg, image/png">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-9">
                            <button type="submit" class="btn btn-primary">Update Product</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
include('../inc/footer.php');
?>
