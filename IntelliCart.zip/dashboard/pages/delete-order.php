<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $orderId = $_GET['id'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // تعطيل القيد الأجنبي مؤقتًا
    $conn->query("SET foreign_key_checks = 0");

    // استعلام SQL لحذف الطلب
    $sql = "DELETE FROM orders WHERE order_id = $orderId";

    if ($conn->query($sql) === TRUE) {
        echo "The order was deleted successfully";
    } else {
        echo "Error deleting order: " . $conn->error;
    }

    // إعادة تمكين القيد الأجنبي
    $conn->query("SET foreign_key_checks = 1");

    $conn->close();

    // إعادة التوجيه إلى صفحة orders.php بعد الحذف
    header("Location: orders.php");
    exit();
} else {
    echo "Invalid request.";
}
?>
