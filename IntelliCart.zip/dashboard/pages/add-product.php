<?php
include('../inc/header.php');
?>

                        <!-- PAGE-HEADER -->
                        <div class="page-header">
                            <h1 class="page-title">Add Product</h1>
                            <div>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Add Product</li>
                                </ol>
                            </div>
                        </div>
                        <!-- PAGE-HEADER END -->


                        <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $productName = $_POST['product_name'];
    $price = $_POST['price'];
    $categoryID = $_POST['category_id'];
    $description = $_POST['description'];

    // استعراض الملف المرفوع
    $image = $_FILES['image']['tmp_name'];
    $imgContent = addslashes(file_get_contents($image));

    if (empty($productName) || empty($price) || empty($categoryID) || empty($description)) {
        echo "يرجى تعبئة جميع الحقول.";
    } else {
        $dateAdded = date("Y-m-d");

        $sql = "INSERT INTO products (PD_name, price, category_id, description, date_added, image) VALUES ('$productName', $price, $categoryID, '$description', '$dateAdded', '$imgContent')";

        if ($conn->query($sql) === TRUE) {
            echo "Product added successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    $conn->close();
}
?>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Add New Product</div>
            </div>
            <div class="card-body">
                <form method="post" action="" enctype="multipart/form-data">
                    <div class="row mb-4">
                        <label class="col-md-3 form-label">Product Name :</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" name="product_name" placeholder="Product Name" required>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-md-3 form-label">Price :</label>
                        <div class="col-md-9">
                            <input type="number" class="form-control" name="price" required>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-md-3 form-label">Categories :</label>
                        <div class="col-md-9">
                            <select name="category_id" class="form-control form-select select2" data-bs-placeholder="Select Category" required>
                                <option value="">Select Category</option>
                                <option value="1">Men</option>
                                <option value="2">Women</option>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-md-3 form-label mb-4">Product Description :</label>
                        <div class="col-md-9 mb-4">
                            <textarea class="content" name="description" required></textarea>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-md-3 form-label">Product Image :</label>
                        <div class="col-md-9">
                            <input type="file" class="form-control" name="image" accept=".jpg, .png, image/jpeg, image/png" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3"></div>
                        <div class="col-md-9">
                            <button type="submit" class="btn btn-primary">Add Product</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>




<?php
include('../inc/footer.php');
?>