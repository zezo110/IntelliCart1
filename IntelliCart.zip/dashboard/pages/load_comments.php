<?php
include('vendor/autoload.php');
use Sentiment\Analyzer;

$obj = new Analyzer();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['product_name'])) {
    $productName = $_GET['product_name'];

    $sql = "SELECT * FROM product_ratings WHERE comment LIKE '%$productName%'";
    $result = $conn->query($sql);
    $comments = [];
    while ($row = $result->fetch_assoc()) {
        $comments[] = $row['comment'];
    }

    $analysisResults = [];
    foreach ($comments as $comment) {
        $result = $obj->getSentiment($comment);
        $total = $result['neg'] + $result['pos'] + $result['neu'];
        if ($total > 0) { // عشان اتجنب القسمة على صفر
            $analysisResults[] = [
                'comment' => $comment,
                'negative' => round(($result['neg'] / $total) * 100, 2), // مقسوم على الإجمالي، مضروب في 100 بدقة رقمين عشريين لإظهار النسبة المئوية
                'positive' => round(($result['pos'] / $total) * 100, 2),
                'neutral' => round(($result['neu'] / $total) * 100, 2)
            ];
        }
    }

    if (!empty($analysisResults)) {
        echo '<div id="comments-container">';
        $result = $analysisResults[0]; 
        echo '<h2>Comment: ' . $result['comment'] . '</h2>';
        echo '<h2>Negative: <span style="color: red;">' . $result['negative'] . '%</span></h2>';
        echo '<h2>Positive: <span style="color: green;">' . $result['positive'] . '%</span></h2>';
        echo '<h2>Neutral: <span style="color: gray;">' . $result['neutral'] . '%</span></h2>';
        echo '</div>';
    } else {
        echo '<p>No analysis results found for product: ' . $productName . '</p>';
    }
} else {
    echo '<p>No analysis results found.</p>';
}
?>
