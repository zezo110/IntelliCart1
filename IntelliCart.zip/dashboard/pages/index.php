<!DOCTYPE html>
<head>
  <meta charset="utf-8">
  <title>Dashboard</title>
</head>
</html>
<?php
include('../inc/header.php');
?>
                        <!-- PAGE-HEADER -->
                        <div class="page-header">
                            <h1 class="page-title">Dashboard</h1>
                            <div>
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                                </ol>
                            </div>
                        </div>
                        <!-- PAGE-HEADER END -->

                        <?php
// اتصال بقاعدة البيانات
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// إحصائيات المستخدمين
$sqlUsers = "SELECT COUNT(*) as totalUsers FROM user_info";
$resultUsers = $conn->query($sqlUsers);
$rowUsers = $resultUsers->fetch_assoc();
$totalUsers = $rowUsers['totalUsers'];

// إحصائيات الطلبات
$sqlOrders = "SELECT COUNT(*) as totalOrders FROM orders";
$resultOrders = $conn->query($sqlOrders);
$rowOrders = $resultOrders->fetch_assoc();
$totalOrders = $rowOrders['totalOrders'];

// إحصائيات المنتجات
$sqlProducts = "SELECT COUNT(*) as totalProducts FROM products";
$resultProducts = $conn->query($sqlProducts);
$rowProducts = $resultProducts->fetch_assoc();
$totalProducts = $rowProducts['totalProducts'];

// إحصائيات المراجعات
$sqlReviews = "SELECT COUNT(*) as totalReviews FROM product_ratings";
$resultReviews = $conn->query($sqlReviews);
$rowReviews = $resultReviews->fetch_assoc();
$totalReviews = $rowReviews['totalReviews'];

// إغلاق الاتصال بقاعدة البيانات
$conn->close();
?>

<!-- ROW-1 -->
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xl-12">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xl-3">
                <div class="card overflow-hidden">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="mt-2">
                                <h6 class="">Total Users</h6>
                                <h2 class="mb-0 number-font"><?php echo $totalUsers; ?></h2>
                            </div>
                            <!-- ... (متابعة الكود) -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xl-3">
                <div class="card overflow-hidden">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="mt-2">
                                <h6 class="">Total Products</h6>
                                <h2 class="mb-0 number-font"><?php echo $totalProducts; ?></h2>
                            </div>
                            <!-- ... (متابعة الكود) -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xl-3">
                <div class="card overflow-hidden">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="mt-2">
                                <h6 class="">Total Orders</h6>
                                <h2 class="mb-0 number-font"><?php echo $totalOrders; ?></h2>
                            </div>
                            <!-- ... (متابعة الكود) -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xl-3">
                <div class="card overflow-hidden">
                    <div class="card-body">
                        <div class="d-flex">
                            <div class="mt-2">
                                <h6 class="">Total Reviews</h6>
                                <h2 class="mb-0 number-font"><?php echo $totalReviews; ?></h2>
                            </div>
                            <!-- ... (متابعة الكود) -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- ROW-1 END -->


                        <!-- ROW-4 -->
                        <div class="row">
    <div class="col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title mb-0">Products</h3>
            </div>
            <div class="card-body pt-4">
                <div class="grid-margin">
                    <div class="">
                        <div class="panel panel-primary">
                            <div class="tab-menu-heading border-0 p-0">
                            </div>
                            <div class="panel-body tabs-menu-body border-0 pt-0">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="tab5">
                                        <div class="table-responsive">
                                            <table id="data-table" class="table table-bordered text-nowrap mb-0">
                                                <thead class="border-top">
                                                    <tr>
                                                        <th class="bg-transparent border-bottom-0">Product</th>
                                                        <th class="bg-transparent border-bottom-0">Date</th>
                                                        <th class="bg-transparent border-bottom-0">Amount</th>
                                                        <th class="bg-transparent border-bottom-0">Action</th>
                                                    </tr>
                                                </thead>
                                                <?php
                                                // قم بتوصيل قاعدة البيانات هنا
                                                $servername = "localhost";
                                                $username = "root";
                                                $password = "";
                                                $dbname = "user";

                                                $conn = new mysqli($servername, $username, $password, $dbname);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }

                                                // استعلام SQL لاسترجاع أحدث 5 منتجات
                                                $sql = "SELECT * FROM products ORDER BY date_added DESC LIMIT 5";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    echo '<tbody>';
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo '<tr class="border-bottom">';
                                                        echo '<td>';
                                                        echo '<div class="d-flex">';
                                                        echo '<span class="avatar bradius" style="background-image: url(data:image/png;base64,' . base64_encode($row['image']) . ')"></span>';
                                                        echo '<div class="ms-3 mt-0 mt-sm-2 d-block">';
                                                        echo '<h6 class="mb-0 fs-14 fw-semibold">' . $row['PD_name'] . '</h6>';
                                                        echo '</div>';
                                                        echo '</div>';
                                                        echo '</td>';
                                                        echo '<td><span class="mt-sm-2 d-block">' . $row['date_added'] . '</span></td>';
                                                        echo '<td><span class="fw-semibold mt-sm-2 d-block">$' . $row['price'] . '</span></td>';
                                                        echo '<td>';
                                                        echo '<div class="g-2">';
                                                        echo '<a class="btn text-primary btn-sm" href="edit-product.php?id=' . $row['id'] . '" data-bs-toggle="tooltip" data-bs-original-title="Edit"><span class="fe fe-edit fs-14"></span></a>';
                                                        echo '<a class="btn text-danger btn-sm" href="delete-product.php?id=' . $row['id'] . '" data-bs-toggle="tooltip" data-bs-original-title="Delete"><span class="fe fe-trash-2 fs-14"></span></a>';
                                                        echo '</div>';
                                                        echo '</td>';
                                                        echo '</tr>';
                                                    }
                                                    echo '</tbody>';
                                                } else {
                                                    echo '<p>No products found.</p>';
                                                }

                                                $conn->close();
                                                ?>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



