<?php
include('vendor/autoload.php');
use Sentiment\Analyzer;

$obj = new Analyzer();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['product_id'])) {
    $product_id = $_GET['product_id'];

    $sql = "SELECT * FROM product_ratings WHERE product_id = $product_id";
    $result = $conn->query($sql);
    $comments = [];
    while ($row = $result->fetch_assoc()) {
        $comments[] = $row['comment'];
    }

    $analysisResults = [];
    foreach ($comments as $comment) {
        $result = $obj->getSentiment($comment);
        $analysisResults[] = [
            'comment' => $comment,
            'negative' => $result['neg'],
            'positive' => $result['pos'],
            'neutral' => $result['neu']
        ];
    }

    $positiveCount = $negativeCount = $neutralCount = 0;
    foreach ($analysisResults as $result) {
        $positiveCount += $result['positive'];
        $negativeCount += $result['negative'];
        $neutralCount += $result['neutral'];
    }

    $totalCount = $positiveCount + $negativeCount + $neutralCount;
    $positivePercentage = ($positiveCount / $totalCount) * 100;
    $negativePercentage = ($negativeCount / $totalCount) * 100;
    $neutralPercentage = ($neutralCount / $totalCount) * 100;

    foreach ($analysisResults as $result) {
        echo '<h2>Comment: ' . $result['comment'] . '</h2>';
        echo '<h2>Negative: ' . $result['negative'] . '</h2>';
        echo '<h2>Positive: ' . $result['positive'] . '</h2>';
        echo '<h2>Neutral: ' . $result['neutral'] . '</h2>';
    }

    // Display the Google Charts bar chart
    echo '
    <html>
        <head>
            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
            <script type="text/javascript">
                google.charts.load("current", {packages:["corechart"]});
                google.charts.setOnLoadCallback(drawChart);
                function drawChart() {
                    var data = google.visualization.arrayToDataTable([
                        ["Sentiment", "Percentage"],
                        ["Positive", ' . $positivePercentage . '],
                        ["Negative", ' . $negativePercentage . '],
                        ["Neutral", ' . $neutralPercentage . ']
                    ]);

                    var options = {
                        title: "Sentiment Analysis",
                        width: 400,
                        height: 300
                    };

                    var chart = new google.visualization.BarChart(document.getElementById("chart"));
                    chart.draw(data, options);
                }
            </script>
        </head>
        <body>
            <div id="chart"></div>
        </body>
    </html>';
} else {
    echo '<p>No analysis results found.</p>';
}
?>