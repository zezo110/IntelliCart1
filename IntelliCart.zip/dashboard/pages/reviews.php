<?php
include('../inc/header.php');
?>

<!-- PAGE-HEADER -->
<div class="page-header">
    <h1 class="page-title">Product Ratings</h1>
    <div>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Product Ratings</li>
        </ol>
    </div>
</div>
<!-- PAGE-HEADER END -->

<div class="row">
    <div class="col-12 col-sm-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title mb-0">Product Ratings</h3>
            </div>
            <div class="card-body pt-4">
                <div class="grid-margin">
                    <div class="">
                        <div class="panel panel-primary">
                            <div class="tab-menu-heading border-0 p-0">
                            </div>
                            <div class="panel-body tabs-menu-body border-0 pt-0">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="tab5">
                                        <div class="table-responsive">
                                            <table id="data-table" class="table table-bordered text-nowrap mb-0">
                                                <thead class="border-top">
                                                    <tr>
                                                        <th class="bg-transparent border-bottom-0">Email</th>
                                                        <th class="bg-transparent border-bottom-0">Product</th>
                                                        <th class="bg-transparent border-bottom-0">Rate</th>
                                                        <th class="bg-transparent border-bottom-0">Comment</th>
                                                        <th class="bg-transparent border-bottom-0">Date</th>
                                                        <th class="bg-transparent border-bottom-0">Action</th>
                                                    </tr>
                                                </thead>
                                                <?php
                                                // قم بتوصيل قاعدة البيانات هنا
                                                $servername = "localhost";
                                                $username = "root";
                                                $password = "";
                                                $dbname = "user";

                                                $conn = new mysqli($servername, $username, $password, $dbname);
                                                if ($conn->connect_error) {
                                                    die("Connection failed: " . $conn->connect_error);
                                                }

                                                // استعلام SQL لاسترجاع المراجعات
                                                $sql = "SELECT * FROM product_ratings";
                                                $result = $conn->query($sql);

                                                if ($result->num_rows > 0) {
                                                    echo '<tbody>';
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo '<tr class="border-bottom">';
                                                        echo '<td>' . $row['user_email'] . '</td>';
                                                        echo '<td>' . getProductTitle($row['product_id'], $conn) . '</td>';
                                                        echo '<td>' . $row['rating'] . '</td>';
                                                        echo '<td>' . $row['comment'] . '</td>';
                                                        echo '<td>' . $row['rating_date'] . '</td>';
                                                        echo '<td>';
                                                        echo '<div class="g-2">';
                                                        echo '<a class="btn text-danger btn-sm" href="delete-rating.php?rating_id=' . $row['rating_id'] . '" data-bs-toggle="tooltip" data-bs-original-title="Delete"><span class="fe fe-trash-2 fs-14"></span></a>';
                                                        echo '</div>';
                                                        echo '</td>';
                                                        echo '</tr>';
                                                    }
                                                    echo '</tbody>';
                                                } else {
                                                    echo '<p>No ratings found.</p>';
                                                }

                                                $conn->close();

                                                function getProductTitle($productId, $connection)
                                                {
                                                    $query = "SELECT PD_name FROM products WHERE id = ?";
                                                    $stmt = $connection->prepare($query);
                                                    $stmt->bind_param("i", $productId);
                                                    $stmt->execute();
                                                    $result = $stmt->get_result();
                                                    if ($row = $result->fetch_assoc()) {
                                                        return $row['PD_name'];
                                                    } else {
                                                        return 'Unknown Product';
                                                    }
                                                }
                                                ?>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include('../inc/footer.php');
?>
