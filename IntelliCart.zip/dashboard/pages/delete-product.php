<?php
include('../inc/header.php');

// الاتصال بقاعدة البيانات
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "user";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$productId = $_GET['id'];

// استعلام SQL للحصول على قائمة الطلبات التي تحتوي على المنتج
$sqlOrders = "SELECT order_id FROM order_items WHERE product_id = '$productId'";
$resultOrders = $conn->query($sqlOrders);

// حذف السجلات في جدول order_items ذات الصلة
while ($rowOrder = $resultOrders->fetch_assoc()) {
    $orderId = $rowOrder['order_id'];
    $sqlDeleteOrderItem = "DELETE FROM order_items WHERE order_id = '$orderId' AND product_id = '$productId'";
    $conn->query($sqlDeleteOrderItem);
}

// حذف المنتج من جدول products
$sqlDeleteProduct = "DELETE FROM products WHERE id = '$productId'";
if ($conn->query($sqlDeleteProduct) === TRUE) {
    echo "The product was deleted successfully";
} else {
    echo "Error deleting product: " . $conn->error;
}

$conn->close();
?>

<!-- صفحة حذف المنتج -->
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title">Delete Product</div>
            </div>
            <div class="card-body">
                <p>Are you Sure to delete the product?</p>
                <form method="post" action="">
                    <!-- إضافة حقل مخفي لتمرير ID المنتج -->
                    <input type="hidden" name="product_id" value="<?php echo $productData['id']; ?>">

                    <button type="submit" class="btn btn-danger">Delete Product</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
include('../inc/footer.php');
?>
