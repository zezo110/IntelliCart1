<?php

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['email'])) {
    $emailToDelete = $_GET['email'];

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "user";

    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // استعلام SQL لحذف المستخدم
    $sql = "DELETE FROM user_info WHERE email = '$emailToDelete'";

    if ($conn->query($sql) === TRUE) {
        echo "user account deleted successfully";

        // إعادة التوجيه إلى صفحة customers.php بعد حذف المستخدم
        header("Location: customers.php");
        exit();
    } else {
        echo "Error occured when try delete account ser. " . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid request.";
}
?>