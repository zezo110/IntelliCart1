<?php
session_start(); // بدء جلسة PHP
$userLoggedIn = isset($_SESSION['email']);
$userEmail = $userLoggedIn ? $_SESSION['email'] : '';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="ecommerce.css">
    <link href='https://cdn.jsdelivr.net/npm/boxicons@2.0.5/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-eW/4WUd5S22Q6tyJTyvPWt2kZDg2jM5X8b5OjcdLzB7B1jIsuHb/WL1ABaO3N0rQa5sJ/7PL5lFPi5MvC+BnA2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-eW/4WUd5S22Q6tyJTyvPWt2kZDg2jM5X8b5OjcdLzB7B1jIsuHb/WL1ABaO3N0rQa5sJ/7PL5lFPi5MvC+BnA2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Ecommerce Website</title>
</head>
<body>
    <header class="l-header">
        <nav class="nav bd-grid">
            <div>
                <a href="index.php" class="nav__logo"><i class='bx bxs-chevrons-down'></i>IntelliCart<i class='bx bxs-chevrons-up'></i></a>
            </div>

            <div class="nav__menu" id="nav-menu">
                <ul class="nav__list">
                    <li class="nav__item"><a href="index.php" class="nav__link active">Home</a></li>
                    <li class="nav__item"><a href="products.php" class="nav__link">products</a></li>
                    <?php if ($userLoggedIn): ?>
                        <li class="nav__item"><a href="profile.php" class="nav__link">Welcome, <?= htmlspecialchars($userEmail) ?></a></li>
                    <?php else: ?>
                        <li class="nav__item"><a href="log.html" class="nav__link">Login / Signup</a></li>
                    <?php endif; ?>
                </ul>
            </div>

            <div>
            <a href="cart.php"> 
                <i class='bx bx-cart nav__cart'></i>
            </a>
            <i class='bx bx-menu nav__toggle' id="nav-toggle"></i>
            </div>
        </nav>
    </header>
