<footer>
<div class="footer__container bd-grid">
<link rel="stylesheet" href="ecommerce.css">
			<div class="footer__box">
				<h3 class="footer__title">IntelliCart</h3>
				<p class="footer__deal">Products store</p>
				<a href="#"><img src="img/footerstore1.png" alt="" class="footer__store"/></a>
				<a href="#"><img src="img/footerstore2.png" alt="" class="footer__store"/></a>
			</div>

			<div class="footer__box">
				<h3 class="footer__title">EXPLORE</h3>
				<ul>
					<li><a href="index.php" class="footer__link">Home</a></li>
					<li><a href="products.php" class="footer__link">Featured</a></li>
					<li><a href="products.php" class="footer__link">New</a></li>
				</ul>
			</div>

			

			<div class="footer__box">
				<h3 class="footer__title">FOLLOW</h3>
				<a href="#" class="footer__social"><i class="bx bxl-facebook-square"></i></a>
				<a href="#" class="footer__social"><i class="bx bxl-instagram-alt"></i></a>
				<a href="#" class="footer__social"><i class="bx bxl-twitter"></i></a>
				<a href="#" class="footer__social"><i class='bx bxl-pinterest-alt'></i></a>
				
			</div>
		</div>
    </footer>
</body>
</html>